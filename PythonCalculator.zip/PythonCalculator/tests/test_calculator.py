
from src.calculator import add, subtract, multiply, divide

def test():
    assert add(1, 2) == 3
    assert subtract(5, 3) == 2
    assert multiply(4, 3) == 12
    assert divide(6, 2) == 3
    assert divide(5, 0) == "Error"
    print("All tests passed.")

if __name__ == "__main__":
    test()
