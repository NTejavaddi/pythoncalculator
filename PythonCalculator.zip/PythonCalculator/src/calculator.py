
def add(a, b): return a + b
def subtract(a, b): return a - b
def multiply(a, b): return a * b
def divide(a, b): return "Error" if b == 0 else a / b

def calculator():
    print("Simple Calculator")
    a = float(input("Enter first number: "))
    op = input("Enter operation (+, -, *, /): ")
    b = float(input("Enter second number: "))
    ops = {'+': add, '-': subtract, '*': multiply, '/': divide}
    print("Result:", ops.get(op, lambda a, b: "Invalid")(a, b))
