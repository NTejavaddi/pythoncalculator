# PythonCalculator

A simple CLI calculator built with Python.